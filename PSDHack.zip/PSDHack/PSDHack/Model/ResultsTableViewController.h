//
//  ResultsTableViewController.h
//  PSDHack
//
//  Created by Josky Jara on 11/30/14.
//  Copyright (c) 2014 PSD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResultsTableViewController : UITableViewController

@end
